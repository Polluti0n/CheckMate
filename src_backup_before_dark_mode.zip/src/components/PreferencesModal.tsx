import React, { useState, useEffect, useMemo, useRef } from 'react';
import { UserPreferences, CheckField, CardLayoutZone, UserProfile, Check, CheckStatus, CheckCategory, CheckViewOptions, CheckFontTheme, CheckBackground, CheckOverlayZone, CheckFooterZone, CheckViewLayoutZone, CardStyle, Flag } from '../types';
import { XMarkIcon, UserCircleIcon, PencilIcon, ProcessingLoaderIcon, DocumentTextIcon, CheckBadgeIcon } from './icons'; 
import { AVAILABLE_CARD_FIELDS, DEFAULT_PREFERENCES, ALL_CHECK_FIELDS } from '../constants';
import {
  draggable,
  dropTargetForElements,
  monitorForElements,
} from '@atlaskit/pragmatic-drag-and-drop/element/adapter';
import { combine } from '@atlaskit/pragmatic-drag-and-drop/combine';
import { pointerOutsideOfPreview } from '@atlaskit/pragmatic-drag-and-drop/element/pointer-outside-of-preview';
import { setCustomNativeDragPreview } from '@atlaskit/pragmatic-drag-and-drop/element/set-custom-native-drag-preview';
import * as firestoreService from '../services/firestoreService';
import { CheckCardAsCheck } from './CheckDashboard';
import ImageCropperModal from './ImageCropperModal';
import { ClassicCard, LedgerCard, ModernCard, CardZoneProps } from './CardStyles';

interface PreferencesModalProps {
    isOpen: boolean;
    onClose: () => void;
    currentPreferences: UserPreferences;
    onSave: (newPreferences: Partial<UserPreferences>) => void;
    userEmail: string | null;
    currentUser: UserProfile | null;
}

type DragState = { type: 'idle' } | { type: 'dragging', fieldKey: CheckField | 'flags' | 'category', sourceZone?: CardLayoutZone | CheckViewLayoutZone };
type FieldDef = { key: CheckField | 'flags' | 'category', label: string };
type Tab = 'Profile' | 'Appearance' | 'Notifications';

const DraggableField = ({ field, isDragging, sourceZone }: { field: FieldDef, isDragging: boolean, sourceZone?: CardLayoutZone | CheckViewLayoutZone }) => {
    const ref = useRef<HTMLDivElement>(null);
    useEffect(() => {
        const el = ref.current;
        if (!el) return;
        return draggable({
            element: el,
            getInitialData: () => ({ type: 'field', fieldKey: field.key, sourceZone }),
             onGenerateDragPreview: ({ nativeSetDragImage }) => {
                setCustomNativeDragPreview({
                    nativeSetDragImage,
                    render: ({ container }) => {
                        const previewEl = document.createElement('div');
                        previewEl.className = "px-3 py-1.5 bg-white rounded-md shadow-lg ring-1 ring-slate-300 font-medium text-xs text-slate-800";
                        previewEl.textContent = field.label;
                        container.appendChild(previewEl);
                        pointerOutsideOfPreview({ x: '16px', y: '16px' });
                        return () => container.removeChild(previewEl);
                    },
                });
            },
        });
    }, [field.key, sourceZone]);

    return (
        <div ref={ref} className={`px-2 py-1.5 border rounded bg-white hover:bg-slate-50 cursor-grab ${isDragging ? 'opacity-40' : ''} text-xs font-medium text-slate-700 shadow-sm`}>
           {field.label}
        </div>
    );
};

const formatPhoneNumber = (value: string): string => {
  if (!value) return '';
  const cleaned = ('' + value).replace(/\D/g, '');
  const match = cleaned.match(/^(\d{0,3})(\d{0,3})(\d{0,4})$/);
  if (match) {
    const [, area, middle, last] = match;
    let formatted = '';
    if (area) formatted += `(${area}`;
    if (middle) formatted += `) ${middle}`;
    if (last) formatted += `-${last}`;
    return formatted;
  }
  return value;
};

// Mock Data for Previews
const PREVIEW_CHECK: Check = {
    id: 'preview-check',
    payor: 'Legacy Properties LLC',
    payee: 'Acme Landscaping Inc.',
    amount: 1234.56,
    checkNumber: '4092',
    date: new Date().toISOString(),
    memo: 'October Grounds Maintenance',
    category: CheckCategory.MISC_NON_HOMEOWNER_INCOME,
    status: CheckStatus.RECEIVED,
    flags: ['flag-1', 'flag-2'],
    comments: [],
    auditTrail: [],
    lastComment: 'Invoice verified against quote.',
    createdAt: new Date().toISOString(),
    payorAddress: { street: '123 Main St', city: 'Dallas', state: 'TX', zip: '75201' },
    bankName: 'Chase Bank',
    routingNumber: '123456789',
    bankAccountNumber: '987654321',
    signature: true,
    additionalInfo: ''
};

const PREVIEW_FLAGS: Flag[] = [
    { id: 'flag-1', name: 'Urgent', color: 'bg-red-500', textColor: 'text-white' },
    { id: 'flag-2', name: 'Approved', color: 'bg-green-500', textColor: 'text-white' },
];

const PreferencesModal: React.FC<PreferencesModalProps> = ({ isOpen, onClose, currentPreferences, onSave, userEmail, currentUser }) => {
    const [prefs, setPrefs] = useState<UserPreferences>(currentPreferences);
    const [dragState, setDragState] = useState<DragState>({ type: 'idle' });
    const [activeTab, setActiveTab] = useState<Tab>('Appearance'); // Default to Appearance usually for quick edits
    const [isUploading, setIsUploading] = useState(false);
    const [imageToCrop, setImageToCrop] = useState<string | null>(null);

    useEffect(() => setPrefs(currentPreferences), [currentPreferences, isOpen]);

    useEffect(() => {
        return monitorForElements({
            onDragStart: ({ source }) => {
                if (source.data.type === 'field') { 
                    setDragState({ type: 'dragging', fieldKey: source.data.fieldKey as CheckField | 'flags' | 'category', sourceZone: source.data.sourceZone as CardLayoutZone | CheckViewLayoutZone | undefined });
                } 
            },
            onDrop: () => setDragState({ type: 'idle' }),
            onDragEnd: () => setDragState({ type: 'idle' }),
        });
    }, []);

    if (!isOpen) return null;

    const handleSave = () => { 
        onSave(prefs); 
        onClose(); 
    };
    const handleReset = () => setPrefs(DEFAULT_PREFERENCES);
    
    const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        if (name === 'phone') {
            const formattedPhone = formatPhoneNumber(value);
            setPrefs(p => ({...p, profile: {...p.profile, phone: formattedPhone }}));
        } else {
            setPrefs(p => ({...p, profile: {...p.profile, [name]: value }}));
     }
    };
    
    const handleNotificationChange = (key: keyof UserPreferences['notifications'], type: 'inApp' | 'email') => {
        setPrefs(p => {
            const newNotifications = { ...p.notifications };
            newNotifications[key][type] = !newNotifications[key][type];
            return { ...p, notifications: newNotifications };
        });
    };

    const handleProfilePictureSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.addEventListener('load', () => {
            setImageToCrop(reader.result as string);
        });
        reader.readAsDataURL(file);
        e.target.value = '';
    };
    
    const handleConfirmCrop = async (croppedBlob: Blob) => {
        if (!currentUser) return;
        setImageToCrop(null);
        setIsUploading(true);
        try {
            const downloadURL = await firestoreService.uploadProfilePicture(croppedBlob, currentUser.uid);
            const newProfile = { ...prefs.profile, profilePictureUrl: downloadURL };
            await firestoreService.updateUserProfile(currentUser.uid, newProfile);
            const newPrefs = { ...prefs, profile: newProfile };
            setPrefs(newPrefs);
            onSave(newPrefs);
        } catch (error) {
            console.error("Failed to upload cropped profile picture:", error);
        } finally {
            setIsUploading(false);
        }
    };

    const currentCardLayout = prefs.cardLayout || {};
    const placedFieldKeys = Object.values(currentCardLayout);
    const availableCardFields = useMemo(() => AVAILABLE_CARD_FIELDS.filter(field => !placedFieldKeys.includes(field.key)), [placedFieldKeys]);
    
    const handleDropOnCardZone = (targetZone: CardLayoutZone) => {
        if (dragState.type !== 'dragging') return;

        const { fieldKey: draggedFieldKey, sourceZone } = dragState;

        setPrefs(prev => {
            const layout = { ...prev.cardLayout };
            const fieldInTargetZone = layout[targetZone];

            if (draggedFieldKey === fieldInTargetZone) return prev; // Dropped on itself

            // Find where the dragged field is currently, if it's on the card
            const originalZoneOfDraggedField = (Object.keys(layout) as CardLayoutZone[]).find(
                key => layout[key] === draggedFieldKey
            );

            // --- Start Mutation ---
            const newLayout = { ...layout };

            // 1. Clear the original location of the dragged field
            if (originalZoneOfDraggedField) {
                delete newLayout[originalZoneOfDraggedField];
            }

            // 2. Place the dragged field in the target zone
            newLayout[targetZone] = draggedFieldKey as CheckField;

            // 3. If there was a field in the target zone, move it.
            if (fieldInTargetZone) {
                // If the dragged field came from another zone, move the displaced field there (swap).
                if (sourceZone) {
                    newLayout[sourceZone as CardLayoutZone] = fieldInTargetZone;
                }
            }

            return { ...prev, cardLayout: newLayout };
        });
    };

    const handleViewModeChange = (mode: 'card' | 'check') => {
        setPrefs(p => ({ ...p, viewMode: mode }));
    };

    const handleCheckViewVisibilityChange = (option: keyof CheckViewOptions) => {
        setPrefs(p => ({
            ...p,
            checkViewOptions: { ...p.checkViewOptions, [option]: !p.checkViewOptions[option as keyof typeof p.checkViewOptions] }
        }));
    };

    const handleCheckViewChange = (key: keyof CheckViewOptions, value: any) => {
        setPrefs(p => ({ ...p, checkViewOptions: { ...p.checkViewOptions, [key]: value } }));
    };

    const handleDropOnCheckZone = (targetZone: CheckViewLayoutZone) => {
        if (dragState.type !== 'dragging') return;
        const { fieldKey, sourceZone } = dragState;

        setPrefs(prev => {
            const newOverlays = { ...prev.checkViewOptions.overlays };
            const newFooter = { ...prev.checkViewOptions.footer };
            const newLayout: any = { ...newOverlays, ...newFooter };

            if (sourceZone && (sourceZone in newOverlays || sourceZone in newFooter)) {
                delete newLayout[sourceZone as CheckViewLayoutZone];
            }

            newLayout[targetZone] = fieldKey;

            const finalOverlays = { overlayTopRight: newLayout.overlayTopRight, overlayBottomLeft: newLayout.overlayBottomLeft };
            const finalFooter = { footerLeft: newLayout.footerLeft, footerRight: newLayout.footerRight };

            return { ...prev, checkViewOptions: { ...prev.checkViewOptions, overlays: finalOverlays, footer: finalFooter } };
        });
    };

    const handleDropOnAvailable = () => {
        if (dragState.type === 'dragging' && dragState.sourceZone) {
             setPrefs(prev => {
                const newLayout = { ...prev.cardLayout };
                delete newLayout[dragState.sourceZone as CardLayoutZone];
                return { ...prev, cardLayout: newLayout };
            });
        }
    };

    const handleDropOnCheckAvailable = () => {
        if (dragState.type === 'dragging' && dragState.sourceZone && (Object.keys(prefs.checkViewOptions.overlays).includes(dragState.sourceZone as string) || Object.keys(prefs.checkViewOptions.footer).includes(dragState.sourceZone as string))) {
            setPrefs(prev => {
                const newOverlays = { ...prev.checkViewOptions.overlays };
                const newFooter = { ...prev.checkViewOptions.footer };
                if (dragState.sourceZone! in newOverlays) delete newOverlays[dragState.sourceZone as CheckOverlayZone];
                if (dragState.sourceZone! in newFooter) delete newFooter[dragState.sourceZone as CheckFooterZone];
                return { ...prev, checkViewOptions: { ...prev.checkViewOptions, overlays: newOverlays, footer: newFooter } };
            });
        }
    };

    const DropZone = ({ fields, onDrop, title, className }: { fields: FieldDef[], onDrop: () => void, title: string, className?: string }) => {
        const ref = useRef<HTMLDivElement>(null);
        const [isDraggedOver, setIsDraggedOver] = useState(false);
        useEffect(() => {
            const el = ref.current;
            if (!el) return;
            return dropTargetForElements({
                element: el, getIsSticky: () => true,
                onDragEnter: () => setIsDraggedOver(true), onDragLeave: () => setIsDraggedOver(false),
                onDrop: () => { onDrop(); setIsDraggedOver(false); }
            });
        }, [onDrop]);
        return (
            <div className={className}>
                <h4 className="font-semibold text-slate-700 text-sm mb-2">{title}</h4>
                <div ref={ref} className={`p-2 border-2 border-dashed rounded-lg min-h-[100px] transition-colors ${isDraggedOver ? 'border-sky-500 bg-sky-50' : 'border-slate-300'}`}>
                    <div className="flex flex-wrap gap-2">
                        {fields.map(field => <DraggableField key={field.key} field={field} isDragging={dragState.type === 'dragging' && dragState.fieldKey === field.key} />)}
                        {fields.length === 0 && <span className="text-xs text-slate-400 self-center w-full text-center py-4">Drop here to remove</span>}
                    </div>
                </div>
            </div>
        );
    };
    
    const baseCheckFields: CheckField[] = ['payor', 'payee', 'amount', 'checkNumber', 'date', 'memo'];
    const availableFieldsForExtras = useMemo(() => {
        return AVAILABLE_CARD_FIELDS.filter(field => !baseCheckFields.includes(field.key));
    }, []);

    const dataFieldOptions: { key: CheckField | 'flags' | 'category' | 'none', label: string }[] = [
        { key: 'none', label: 'None' },
        { key: 'category', label: 'Category' },
        { key: 'flags', label: 'Flags' },
        ...availableFieldsForExtras,
    ];

    const CheckViewCustomizer = () => {
        const CheckDropZone = ({ zone, onDrop, children, className }: { zone: CheckViewLayoutZone, onDrop: (zone: CheckViewLayoutZone) => void, children: React.ReactNode, className?: string }) => {
            const ref = useRef<HTMLDivElement>(null);
            const [isDraggedOver, setIsDraggedOver] = useState(false);
            const isDragging = dragState.type === 'dragging';
            useEffect(() => {
                const el = ref.current; if (!el) return;
                return dropTargetForElements({
                    element: el, getIsSticky: () => true,
                    canDrop: ({ source }) => source.data.type === 'field',
                    onDragEnter: () => setIsDraggedOver(true), onDragLeave: () => setIsDraggedOver(false),
                    onDrop: () => { onDrop(zone); setIsDraggedOver(false); }
                });
            }, [zone, onDrop]);
            if (!children && !isDragging) return null;
            return (
                <div ref={ref} className={`${className} ${isDraggedOver ? 'bg-sky-100/50 ring-2 ring-sky-400' : ''} ${isDragging && !children ? 'border-2 border-dashed border-slate-300' : ''}`}>
                    {children}
                </div>
            );
        };

        const fontThemeOptions: { key: CheckFontTheme, label: string }[] = [
            { key: 'cursive', label: 'Cursive' },
            { key: 'block', label: 'Block' },
            { key: 'typed', label: 'Typed' },
        ];

        const backgroundOptions: { key: CheckBackground, label: string }[] = [
            { key: 'classic', label: 'Classic' },
            { key: 'modern', label: 'Modern' },
            { key: 'secure', label: 'Secure' },
        ];

        const placedFieldKeys = Object.values({ ...prefs.checkViewOptions.overlays, ...prefs.checkViewOptions.footer });
        const availableCheckFields = useMemo(() => dataFieldOptions.filter(field => field.key !== 'none' && !placedFieldKeys.includes(field.key)), [placedFieldKeys]);

        return (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-1 overflow-y-auto pr-1">
                    <h4 className="font-semibold text-slate-700 text-sm">Options</h4>
                    <div className="space-y-2 mt-1">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                                <label htmlFor="check-font-theme" className="block text-xs font-medium text-slate-600">Font</label>
                                <select id="check-font-theme" value={prefs.checkViewOptions.fontTheme} onChange={(e) => handleCheckViewChange('fontTheme', e.target.value)} className="mt-0.5 block w-full p-1.5 text-xs border-slate-300 rounded-md shadow-sm focus:border-sky-500 focus:ring-sky-500">
                                    {fontThemeOptions.map(opt => <option key={opt.key} value={opt.key}>{opt.label}</option>)}
                                </select>
                            </div>
                            <div>
                                <label htmlFor="check-background" className="block text-xs font-medium text-slate-600">Background</label>
                                <select id="check-background" value={prefs.checkViewOptions.background} onChange={(e) => handleCheckViewChange('background', e.target.value)} className="mt-0.5 block w-full p-1.5 text-xs border-slate-300 rounded-md shadow-sm focus:border-sky-500 focus:ring-sky-500">
                                    {backgroundOptions.map(opt => <option key={opt.key} value={opt.key}>{opt.label}</option>)}
                                </select>
                            </div>
                        </div>
                        <DropZone fields={availableCheckFields} onDrop={handleDropOnCheckAvailable} title="Available Fields" className="border-t pt-2" />
                    </div>
                </div>
                <div className="md:col-span-2">
                    <h4 className="font-semibold text-slate-700 text-sm mb-1">Check Preview</h4>
                    <div className="bg-slate-100 p-2 rounded-lg">
                        <CheckCardAsCheck 
                            check={PREVIEW_CHECK} 
                            isSelected={false} 
                            flags={PREVIEW_FLAGS} 
                            options={prefs.checkViewOptions}
                            isPreview={true}
                            onVisibilityChange={handleCheckViewVisibilityChange}
                            draggableFieldComponent={DraggableField}
                            dropZoneComponent={CheckDropZone}
                            onDropOnZone={handleDropOnCheckZone}
                            dragState={dragState}
                        />
                    </div>
                </div>
            </div>
        );
    };

    const PreferencesZoneWrapper: React.FC<CardZoneProps> = ({ zone, fieldKey, name, className }) => {
        const ref = useRef<HTMLDivElement>(null);
        const [isDraggedOver, setIsDraggedOver] = useState(false);
        const { type: dragType, fieldKey: draggingFieldKey } = dragState;
        const fieldDef = fieldKey ? AVAILABLE_CARD_FIELDS.find(f => f.key === fieldKey) : null;

        useEffect(() => {
            const el = ref.current;
            if (!el) return;

            return combine(
                dropTargetForElements({
                    element: el,
                    getIsSticky: () => true,
                    canDrop: ({ source }) => source.data.type === 'field',
                    onDragEnter: () => setIsDraggedOver(true),
                    onDragLeave: () => setIsDraggedOver(false),
                    onDrop: () => {
                        handleDropOnCardZone(zone);
                        setIsDraggedOver(false);
                    }
                }),
                draggable({
                    element: el,
                    getInitialData: () => ({ type: 'field', fieldKey, sourceZone: zone }),
                    canDrag: () => !!fieldKey,
                    onGenerateDragPreview: ({ nativeSetDragImage }) => {
                        if (!fieldDef) return;
                        setCustomNativeDragPreview({
                            nativeSetDragImage,
                            render: ({ container }) => {
                                const previewEl = document.createElement('div');
                                previewEl.className = "px-3 py-1.5 bg-white rounded-md shadow-lg ring-1 ring-slate-300 font-medium text-xs text-slate-800";
                                previewEl.textContent = fieldDef.label;
                                container.appendChild(previewEl);
                                pointerOutsideOfPreview({ x: '16px', y: '16px' });
                                return () => container.removeChild(previewEl);
                            },
                        });
                    },
                })
            );
        }, [zone, fieldKey, fieldDef]);
        
        const isThisBeingDragged = dragType === 'dragging' && draggingFieldKey === fieldKey;

        if (fieldKey && fieldDef) {
            return (
                <div ref={ref} className={`${className} relative cursor-grab active:cursor-grabbing border border-transparent hover:border-slate-300 rounded ${isDraggedOver ? 'ring-2 ring-sky-400 bg-sky-50' : ''} ${isThisBeingDragged ? 'opacity-40' : ''}`}>
                    <div className="px-2 py-1.5 border rounded bg-white text-xs font-medium text-slate-700 shadow-sm pointer-events-none">
                        {fieldDef.label}
                    </div>
                </div>
            );
        }

        return (
            <div ref={ref} className={`${className} border-2 border-dashed rounded transition-colors flex items-center justify-center min-h-[24px] min-w-[60px] ${isDraggedOver ? 'border-sky-500 bg-sky-50' : 'border-slate-50/50'}`}>
                <span className="text-[10px] text-slate-400 font-medium px-2 select-none">
                    {dragType === 'dragging' ? 'Drop Here' : 'Empty'}
                </span>
            </div>
        );
    };

    const renderContent = () => {
        switch (activeTab) {
            case 'Appearance':
                return (
                    <>
                        <div className="flex items-center justify-between pb-3 border-b mb-3">
                            <div>
                                <h3 className="text-lg font-bold text-slate-800">Appearance</h3>
                                <p className="text-xs text-slate-500">Customize check display.</p>
                            </div>
                            <div className="flex items-center p-1 bg-slate-100 rounded-lg h-8">
                                <button onClick={() => handleViewModeChange('card')} className={`px-3 text-xs font-medium rounded-md flex items-center gap-1.5 h-full transition-colors ${prefs.viewMode === 'card' ? 'bg-white shadow-sm text-sky-600' : 'text-slate-600 hover:bg-slate-200'}`}>
                                    <DocumentTextIcon className="h-4 w-4" />
                                    <span>Cards</span>
                                </button>
                                <button onClick={() => handleViewModeChange('check')} className={`px-3 text-xs font-medium rounded-md flex items-center gap-1.5 h-full transition-colors ${prefs.viewMode === 'check' ? 'bg-white shadow-sm text-sky-600' : 'text-slate-600 hover:bg-slate-200'}`}>
                                    <CheckBadgeIcon className="h-4 w-4" />
                                    <span>Checks</span>
                                </button>
                            </div>
                        </div>
                        
                        {prefs.viewMode === 'card' ? (
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-full overflow-hidden">
                                <div className="md:col-span-1 flex flex-col gap-3 max-h-[60vh] overflow-y-auto">
                                    <DropZone fields={availableCardFields} onDrop={handleDropOnAvailable} title="Available Fields" />
                                    <div>
                                        <h4 className="font-semibold text-slate-700 text-sm mb-2">Style</h4>
                                        <div className="flex flex-col space-y-2">
                                            {(['classic', 'ledger', 'modern'] as CardStyle[]).map(style => (
                                                <button 
                                                    key={style}
                                                    onClick={() => setPrefs(p => ({ ...p, cardStyle: style }))}
                                                    className={`w-full text-xs font-semibold py-1.5 px-3 rounded-md border-2 transition-colors text-left flex items-center justify-between ${prefs.cardStyle === style ? 'border-slate-700 bg-slate-50 text-slate-800' : 'border-slate-200 hover:border-slate-300 text-slate-500'}`}
                                                >
                                                    <span>{style.charAt(0).toUpperCase() + style.slice(1)}</span>
                                                    {prefs.cardStyle === style && <div className="h-2 w-2 rounded-full bg-slate-700"></div>}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                <div className="md:col-span-2 flex flex-col">
                                    <h4 className="font-semibold text-slate-700 text-sm mb-1">Preview</h4>
                                    <div className="bg-slate-100 p-4 rounded-lg flex justify-center items-center flex-grow min-h-[220px]">
                                        <div className="w-full max-w-sm">
                                            {prefs.cardStyle === 'classic' && (
                                                <ClassicCard check={PREVIEW_CHECK} allFlags={PREVIEW_FLAGS} cardLayout={prefs.cardLayout} ZoneComponent={PreferencesZoneWrapper} />
                                            )}
                                            {prefs.cardStyle === 'ledger' && (
                                                <LedgerCard check={PREVIEW_CHECK} allFlags={PREVIEW_FLAGS} cardLayout={prefs.cardLayout} ZoneComponent={PreferencesZoneWrapper} />
                                            )}
                                            {prefs.cardStyle === 'modern' && (
                                                <ModernCard check={PREVIEW_CHECK} allFlags={PREVIEW_FLAGS} cardLayout={prefs.cardLayout} ZoneComponent={PreferencesZoneWrapper} />
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <CheckViewCustomizer />
                        )}
                    </>
                );
            case 'Profile':
                return (
                     <div className="pt-2">
                        <div className="flex flex-col md:flex-row gap-6">
                            {/* Left Column: Image & Basic Info */}
                            <div className="flex-shrink-0 flex flex-col items-center md:items-start space-y-3">
                                <div className="relative group">
                                    {isUploading ? (
                                        <div className="h-20 w-20 rounded-full bg-slate-200 flex items-center justify-center"><ProcessingLoaderIcon /></div>
                                    ) : prefs.profile.profilePictureUrl ? (
                                        <img src={prefs.profile.profilePictureUrl} alt="Profile" className="h-20 w-20 rounded-full object-cover ring-2 ring-slate-100" />
                                    ) : (
                                        <UserCircleIcon className="h-20 w-20 text-slate-300" />
                                    )}
                                    <label htmlFor="profile-picture-upload" className="absolute -bottom-1 -right-1 cursor-pointer bg-white p-1.5 rounded-full shadow-sm border border-slate-200 hover:bg-slate-50 text-slate-500 hover:text-sky-600 transition-colors">
                                        <PencilIcon className="h-3 w-3" />
                                        <input id="profile-picture-upload" name="profile-picture-upload" type="file" className="sr-only" accept="image/*" onChange={handleProfilePictureSelect} disabled={isUploading} />
                                    </label>
                                </div>
                                <div className="text-center md:text-left">
                                    <p className="text-xs font-medium text-slate-500">Profile Picture</p>
                                    <p className="text-[10px] text-slate-400">Used for batch reports</p>
                                </div>
                            </div>

                            {/* Right Column: Form Inputs */}
                            <div className="flex-grow">
                                <h3 className="text-lg font-bold text-slate-800 mb-4">Personal Information</h3>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-3">
                                    <div>
                                        <label htmlFor="firstName" className="block text-xs font-medium text-slate-700">First Name</label>
                                        <input type="text" name="firstName" id="firstName" value={prefs.profile.firstName} onChange={handleProfileChange} className="mt-1 p-2 block w-full rounded-md border border-slate-300 shadow-sm focus:border-sky-500 focus:ring-sky-500 text-sm" />
                                    </div>
                                    <div>
                                        <label htmlFor="lastName" className="block text-xs font-medium text-slate-700">Last Name</label>
                                        <input type="text" name="lastName" id="lastName" value={prefs.profile.lastName} onChange={handleProfileChange} className="mt-1 p-2 block w-full rounded-md border border-slate-300 shadow-sm focus:border-sky-500 focus:ring-sky-500 text-sm" />
                                    </div>
                                    <div>
                                        <label htmlFor="phone" className="block text-xs font-medium text-slate-700">Phone</label>
                                        <input type="tel" name="phone" id="phone" value={prefs.profile.phone} onChange={handleProfileChange} maxLength={14} placeholder="(xxx) xxx-xxxx" className="mt-1 p-2 block w-full rounded-md border border-slate-300 shadow-sm focus:border-sky-500 focus:ring-sky-500 text-sm" />
                                    </div>
                                    <div>
                                        <label htmlFor="branch" className="block text-xs font-medium text-slate-700">Branch</label>
                                        <input type="text" name="branch" id="branch" value={prefs.profile.branch} onChange={handleProfileChange} className="mt-1 p-2 block w-full rounded-md border border-slate-300 shadow-sm focus:border-sky-500 focus:ring-sky-500 text-sm" />
                                    </div>
                                    <div className="sm:col-span-2">
                                        <label htmlFor="email" className="block text-xs font-medium text-slate-700">Email</label>
                                        <input type="email" name="email" id="email" value={userEmail || ''} disabled className="mt-1 p-2 block w-full rounded-md border border-slate-300 shadow-sm text-sm bg-slate-100 text-slate-500 cursor-not-allowed" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                );
            case 'Notifications':
                const notificationTypes: { key: keyof UserPreferences['notifications']; label: string }[] = [
                    { key: 'allUpdates', label: 'All Updates' },
                    { key: 'newComments', label: 'New Comments' },
                    { key: 'flagChanges', label: 'Flag Changes' },
                    { key: 'newChecks', label: 'New Checks' },
                    { key: 'statusChanges', label: 'Status Changes' },
                    { key: 'newBatches', label: 'Batch Processed' },
                ];
                return (
                     <div>
                        <div className="pb-3 border-b">
                             <h3 className="text-lg font-bold text-slate-800">Notifications</h3>
                             <p className="text-xs text-slate-500">Alert preferences.</p>
                        </div>
                        <div className="mt-3">
                            <table className="min-w-full">
                                <thead className="border-b">
                                    <tr>
                                        <th className="py-2 text-left text-xs font-semibold text-slate-600">Action</th>
                                        <th className="py-2 text-center text-xs font-semibold text-slate-600">In-App</th>
                                        <th className="py-2 text-center text-xs font-semibold text-slate-600">Email</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {notificationTypes.map(({ key, label }) => (
                                        <tr key={key} className="border-b border-slate-100 hover:bg-slate-50">
                                            <td className="py-2 text-sm font-medium text-slate-800">{label}</td>
                                            <td className="py-2 text-center">
                                                <input type="checkbox" className="h-4 w-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500" checked={prefs.notifications[key].inApp} onChange={() => handleNotificationChange(key, 'inApp')} />
                                            </td>
                                            <td className="py-2 text-center">
                                                <input type="checkbox" className="h-4 w-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500" checked={prefs.notifications[key].email} onChange={() => handleNotificationChange(key, 'email')} />
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                );
            default:
                return null;
        }
    }

    return (
        <>
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity z-50 flex items-center justify-center p-4">
                {/* Changed h-[90dvh] to auto height with max-h constraint for better centering and less whitespace */}
                <div className="relative w-full max-w-3xl bg-white rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
                    {/* Header */}
                    <div className="flex items-start justify-between px-4 py-3 border-b border-slate-100 flex-shrink-0 bg-white z-10">
                        <div><h3 className="text-lg font-bold text-slate-800">Settings</h3></div>
                        <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"><XMarkIcon className="h-5 w-5" /></button>
                    </div>

                    {/* Tabs */}
                    <div className="border-b border-slate-200 px-4 flex-shrink-0">
                        <nav className="-mb-px flex space-x-6">
                            {([ 'Appearance', 'Profile', 'Notifications'] as Tab[]).map(tab => (
                                <button key={tab} onClick={() => setActiveTab(tab)} className={`whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm transition-colors ${activeTab === tab ? 'border-sky-500 text-sky-600' : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'}`}>
                                    {tab}
                                </button>))}
                        </nav>
                    </div>

                    {/* Main Content - Scrollable */}
                    <div className="flex-1 overflow-y-auto px-4 py-3 scrollbar-thin scrollbar-thumb-slate-200 scrollbar-track-transparent">
                       {renderContent()}
                    </div>

                    {/* Footer */}
                     <div className="bg-gray-50 px-4 py-3 flex flex-shrink-0 justify-between items-center border-t border-slate-100">
                        <button type="button" onClick={handleReset} className="text-xs font-medium text-slate-500 hover:text-red-600 transition-colors">Reset Defaults</button>
                        <div className="flex gap-2">
                            <button type="button" onClick={onClose} className="rounded-md border border-slate-300 shadow-sm px-3 py-1.5 bg-white text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors">Cancel</button>
                            <button type="button" onClick={handleSave} className="rounded-md border border-transparent shadow-sm px-3 py-1.5 bg-sky-600 text-sm font-medium text-white hover:bg-sky-700 transition-colors">Save Changes</button>
                        </div>
                    </div>
                </div>
            </div>
            <ImageCropperModal
                isOpen={!!imageToCrop}
                imageSrc={imageToCrop}
                onClose={() => setImageToCrop(null)}
                onConfirmCrop={handleConfirmCrop}
            />
        </>
    );
};
                            
export default PreferencesModal;