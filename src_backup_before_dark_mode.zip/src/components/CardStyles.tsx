import React from 'react';
import { Check, Flag, CardLayoutZone, CheckField } from '../types';
import { AVAILABLE_CARD_FIELDS } from '../constants';
import { categoryConfig } from '../formConfig';
import { communityIcon, CalendarDaysIcon, FlagIcon as FlagFilledIcon, HashtagIcon, UsDollarIcon } from './icons';

const USDollar = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' });

// New Interface for the wrapper component (passed from PreferencesModal)
export interface CardZoneProps {
    zone: CardLayoutZone;
    fieldKey: CheckField | null;
    formattedValue: string | null;
    label: string | null;
    className?: string;
    children?: React.ReactNode;
}

interface CardProps {
    check: Check;
    allFlags: Flag[];
    cardLayout: Partial<Record<CardLayoutZone, CheckField>>;
    // Optional: Component to wrap fields (used for Drag-and-Drop in Preferences)
    ZoneComponent?: React.FC<CardZoneProps>;
}

const formatValue = (value: any, key: CheckField): string | null => {
    if (value === undefined || value === null || value === '') return null;
    if (key === 'amount') return USDollar.format(value);
    if (key === 'date' || key === 'createdAt' || key === 'statusUpdatedAt') return new Date(value as string).toLocaleDateString();
    if (key === 'category') return (value as string).replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
    if (key === 'lastComment') return `“${String(value)}”`;
    return String(value);
};

const getField = (check: Check, cardLayout: Partial<Record<CardLayoutZone, CheckField>>, zone: CardLayoutZone) => {
    const fieldKey = cardLayout[zone];
    
    // Even if fieldKey is missing, we return structure for the DropZone to use
    if (!fieldKey) return { value: null, label: null, key: null };

    let value: any;
    if (fieldKey === 'lastComment') {
        if (!check.comments || check.comments.length === 0) {
             value = null; 
        } else {
             value = check.comments[check.comments.length - 1].text;
        }
    } else {
        value = check[fieldKey as keyof Check];
    }

    const formattedValue = formatValue(value, fieldKey);
    const fieldConfig = AVAILABLE_CARD_FIELDS.find(f => f.key === fieldKey);
    const label = fieldConfig?.label || String(fieldKey);
    const icon = fieldConfig?.icon;

    return { value: formattedValue, label, key: fieldKey, icon};
};

const FlagTooltip = ({ flag }: { flag: Flag }) => (
    <div className="group/flag relative inline-block">
        <div className={`p-1 rounded-full ${flag.color} group-hover/flag:scale-110 transition-transform duration-200 cursor-help ring-1 ring-black/5`}>
            <FlagFilledIcon className={`h-2.5 w-2.5 ${flag.textColor}`} />
        </div>
        <div className={`absolute bottom-full left-1/2 z-[60] mb-2 -translate-x-1/2 whitespace-nowrap rounded shadow-lg bg-slate-800 px-2 py-1 text-[10px] font-medium text-white opacity-0 transition-opacity group-hover/flag:opacity-100 pointer-events-none`}>
            {flag.name}
            <div className="absolute top-full left-1/2 -mt-1 h-2 w-2 -translate-x-1/2 rotate-45 bg-slate-800"></div>
        </div>
    </div>
);

const renderFlags = (check: Check, allFlags: Flag[]) => {
    const checkFlags = allFlags.filter(f => check.flags?.includes(f.id));
    if (!checkFlags.length) return null;
    return checkFlags.map(flag => <FlagTooltip key={flag.id} flag={flag} />);
};

// Helper to render either the simple text or the DropZone component
const renderZoneContent = (
    check: Check, 
    layout: Partial<Record<CardLayoutZone, CheckField>>, 
    zone: CardLayoutZone, 
    classes: string, 
    ZoneComponent?: React.FC<CardZoneProps>,
    wrapperClasses?: string // Wrapper div classes if needed for structure
) => {
    const fieldData = getField(check, layout, zone);
    
    // If we have a custom ZoneComponent (Edit Mode), use it
    if (ZoneComponent) {
        return (
            <ZoneComponent 
                zone={zone} 
                fieldKey={fieldData.key} 
                formattedValue={fieldData.value} 
                label={fieldData.label}
                className={`${classes} ${wrapperClasses || ''}`} 
            />
        );
    }

    // Standard Read-Only Mode
    if (!fieldData.value) return null;

    return (
        <div className={wrapperClasses}>
            <p className={classes} title={`${fieldData.label}: ${fieldData.value}`}>
                {fieldData.value}
            </p>
        </div>
    );
};

// ==========================================
// STYLE 1: CLASSIC CARD
// ==========================================
export const ClassicCard: React.FC<CardProps> = ({ check, allFlags, cardLayout, ZoneComponent }) => {
    const categoryInfo = categoryConfig[check.category];
    const borderColor = categoryInfo ? categoryInfo.color.border : 'border-slate-500';
    const flagsContent = renderFlags(check, allFlags);

    return (
        <div className={`bg-white p-2 rounded-md shadow-sm border border-l-4 hover:shadow-lg cursor-pointer active:cursor-grabbing transition-all duration-200 flex flex-col justify-between ${borderColor} hover:scale-105 min-h-[140px]`}>
            <div className="flex flex-col flex-grow space-y-1">
                <div className="flex justify-between items-start gap-2">
                    {/* Title */}
                    {renderZoneContent(check, cardLayout, 'title', "font-semibold text-slate-800 text-base truncate", ZoneComponent, "flex-grow min-w-0")}
                    {/* TopRight */}
                    {renderZoneContent(check, cardLayout, 'topRight', "font-bold text-slate-900 text-base", ZoneComponent, "flex-shrink-0")}
                </div>
                {/* Subtitle */}
                {renderZoneContent(check, cardLayout, 'subtitle', "text-xs text-slate-500 font-medium truncate", ZoneComponent)}
                {/* Body1 */}
                {renderZoneContent(check, cardLayout, 'body1', "text-sm text-slate-700 break-words pt-1", ZoneComponent)}
            </div>
            <div className="flex justify-between items-end mt-1 pt-1 border-t border-slate-100 gap-2">
                {/* FooterLeft */}
                {renderZoneContent(check, cardLayout, 'footerLeft', "text-xs text-slate-500 truncate", ZoneComponent, "flex-grow min-w-0")}
                
                {/* Flags are static for now, typically not draggable in card view */}
                {flagsContent && <div className="flex items-center justify-end ml-auto flex-shrink-0">{flagsContent}</div>}
                
                {/* FooterRight */}
                {renderZoneContent(check, cardLayout, 'footerRight', "text-xs text-slate-500 font-mono ml-2", ZoneComponent, "flex-shrink-0")}
            </div>
        </div>
    );
};

// ==========================================
// STYLE 2: LEDGER CARD
// ==========================================
export const LedgerCard: React.FC<CardProps> = ({ check, allFlags, cardLayout, ZoneComponent }) => {
    const flagsContent = renderFlags(check, allFlags);

    // For Ledger, we need to handle the list items differently because of the dotted lines
    const listZones: CardLayoutZone[] = ['subtitle', 'body1', 'footerLeft', 'footerRight'];
    
    // If in Edit Mode (ZoneComponent exists), show all zones. If View Mode, only show populated ones.
    const activeZones = ZoneComponent 
        ? listZones 
        : listZones.filter(z => getField(check, cardLayout, z).value);

    return (
        <div className="relative bg-[#fcfbf9] rounded shadow-sm hover:shadow-md border border-stone-200 cursor-pointer transition-transform duration-200 hover:scale-[1.02] group font-mono min-h-[180px]">
            <div className="absolute top-0 left-0 right-0 h-1 bg-stone-200 opacity-50 bg-[length:12px_12px] bg-[radial-gradient(circle,transparent_20%,#e7e5e4_20%)] bg-[position:top_center] -mt-1.5 rounded-t-sm"></div>

            <div className="p-3 flex flex-col gap-2">
                <div className="flex justify-between items-baseline border-b-2 border-dashed border-stone-300 pb-2 mb-1 gap-2">
                    <div className="flex flex-col flex-grow min-w-0 gap-1">
                        {/* Using title zone for the main header text */}
                        {renderZoneContent(check, cardLayout, 'title', "font-bold text-stone-800 text-sm truncate", ZoneComponent)}
                    </div>
                    {/* Top Right (Amount) */}
                    {renderZoneContent(check, cardLayout, 'topRight', "text-lg font-bold text-stone-900 tabular-nums tracking-tight", ZoneComponent, "flex-shrink-0")}
                </div>

                <div className="space-y-1.5 text-xs text-stone-600">
                    {activeZones.map((zone, idx) => {
                        const fieldData = getField(check, cardLayout, zone);
                        
                        if (ZoneComponent) {
                            return (
                                <div key={zone} className="flex flex-col mb-1">
                                    <ZoneComponent 
                                        zone={zone} 
                                        fieldKey={fieldData.key} 
                                        formattedValue={fieldData.value} 
                                        label={fieldData.label}
                                        className="text-right truncate" 
                                    />
                                </div>
                            );
                        }

                        return (
                            <div key={zone} className="flex justify-between items-center gap-2">
                                <span className="uppercase text-[10px] font-bold text-stone-400 shrink-0 tracking-wide">{fieldData.label}</span>
                                <div className="flex-grow border-b border-dotted border-stone-300 h-1 mx-1 relative -top-1"></div>
                                <span className="text-right truncate max-w-[60%]">{fieldData.value}</span>
                            </div>
                        );
                    })}
                </div>

                <div className="mt-2 pt-2 border-t-2 border-dashed border-stone-300 flex justify-between items-center">
                    <div className="scale-90 origin-left opacity-80 flex items-center">
                         {flagsContent}
                    </div>
                    {/* Footer Right area usually used for Verified/Date in ledger. We map it above, but this slot is decorative */}
                    <div className="text-[10px] text-stone-400 italic">
                        TRANSACTION RECORD
                    </div>
                </div>
            </div>
            
            <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-[linear-gradient(45deg,transparent_33.333%,#fcfbf9_33.333%,#fcfbf9_66.667%,transparent_66.667%),linear-gradient(-45deg,transparent_33.333%,#fcfbf9_33.333%,#fcfbf9_66.667%,transparent_66.667%)] bg-[length:10px_20px] bg-[position:0_100%] translate-y-full drop-shadow-sm"></div>
        </div>
    );
};

// ==========================================
// HELPER: Color Lookup// ==========================================
// STYLE 3: MODERN CARD (Auto-Sorted)
// ==========================================

// Helper to generate modern chip classes based on color name
const FLAG_THEMES: Record<string, { wrapper: string; text: string; border: string; dot: string }> = {
    red:    { wrapper: 'bg-red-50',    text: 'text-red-700',    border: 'border-red-200',    dot: 'bg-red-500' },
    orange: { wrapper: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200', dot: 'bg-orange-500' },
    amber:  { wrapper: 'bg-amber-50',  text: 'text-amber-700',  border: 'border-amber-200',  dot: 'bg-amber-500' },
    yellow: { wrapper: 'bg-yellow-50', text: 'text-yellow-700', border: 'border-yellow-200', dot: 'bg-yellow-500' },
    lime:   { wrapper: 'bg-lime-50',   text: 'text-lime-700',   border: 'border-lime-200',   dot: 'bg-lime-500' },
    green:  { wrapper: 'bg-green-50',  text: 'text-green-700',  border: 'border-green-200',  dot: 'bg-green-500' },
    emerald:{ wrapper: 'bg-emerald-50',text: 'text-emerald-700',border: 'border-emerald-200',dot: 'bg-emerald-500' },
    teal:   { wrapper: 'bg-teal-50',   text: 'text-teal-700',   border: 'border-teal-200',   dot: 'bg-teal-500' },
    cyan:   { wrapper: 'bg-cyan-50',   text: 'text-cyan-700',   border: 'border-cyan-200',   dot: 'bg-cyan-500' },
    sky:    { wrapper: 'bg-sky-50',    text: 'text-sky-700',    border: 'border-sky-200',    dot: 'bg-sky-500' },
    blue:   { wrapper: 'bg-blue-50',   text: 'text-blue-700',   border: 'border-blue-200',   dot: 'bg-blue-500' },
    indigo: { wrapper: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-200', dot: 'bg-indigo-500' },
    violet: { wrapper: 'bg-violet-50', text: 'text-violet-700', border: 'border-violet-200', dot: 'bg-violet-500' },
    purple: { wrapper: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-200', dot: 'bg-purple-500' },
    fuchsia:{ wrapper: 'bg-fuchsia-50',text: 'text-fuchsia-700',border: 'border-fuchsia-200',dot: 'bg-fuchsia-500' },
    pink:   { wrapper: 'bg-pink-50',   text: 'text-pink-700',   border: 'border-pink-200',   dot: 'bg-pink-500' },
    rose:   { wrapper: 'bg-rose-50',   text: 'text-rose-700',   border: 'border-rose-200',   dot: 'bg-rose-500' },
    default:{ wrapper: 'bg-slate-100', text: 'text-slate-700',  border: 'border-slate-200',  dot: 'bg-slate-500' },
};

const getChipStyles = (bgClass: string) => {
    const match = bgClass.match(/bg-([a-z]+)-?/); 
    const colorName = match ? match[1] : 'default';
    return FLAG_THEMES[colorName] || FLAG_THEMES.default;
};

export const ModernCard: React.FC<CardProps> = ({ check, allFlags, cardLayout, ZoneComponent }) => {    
    const categoryInfo = categoryConfig[check.category];
    const color = categoryInfo ? categoryInfo.color : { text: 'text-slate-600', bg: 'bg-slate-500', bgLight: 'bg-slate-200', glow: 'shadow-slate-500/20' };
    const Icon = categoryInfo ? categoryInfo.icon : communityIcon;
    const subtitle = getField(check, cardLayout, 'subtitle');
    const body1 = getField(check, cardLayout, 'body1');
    const footerLeft = getField(check, cardLayout, 'footerLeft');
    const footerRight = getField(check, cardLayout, 'footerRight');

    // 1. FILTER 
    const checkFlags = allFlags.filter(f => check.flags?.includes(f.id));

    // 2. SORT (Shortest text length first)
    // This helps smaller flags tuck into the remaining space on the first line.
    const sortedFlags = [...checkFlags].sort((a, b) => a.name.length - b.name.length);

    const hasFlags = sortedFlags.length > 0;

    return (
        <div className="relative mt-6 hover:scale-[1.02] transition-transform duration-200 cursor-pointer group min-h-[200px]">
            <div className="bg-white shadow-xl relative rounded-lg overflow-hidden flex flex-col h-full border border-slate-100">
                
                {/* Header */}
                <div className={`p-4 relative flex justify-between items-center ${color.bg}`}>
                    <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-black/15"></div>
                    <div className="relative z-10">
                        <Icon className="w-6 h-6 text-white drop-shadow-md opacity-95" />
                    </div>
                    <div className="z-20">
                        {renderZoneContent(check, cardLayout, 'topRight', "uppercase tracking-widest text-xs text-white bg-black/30 backdrop-blur-sm py-1 px-2 rounded shadow-lg font-bold", ZoneComponent)}
                    </div>
                </div>

                {/* Body */}
                <div className="p-4 text-slate-700 flex flex-col flex-grow justify-between gap-4">
                    <div className="w-full space-y-2">
                        {renderZoneContent(check, cardLayout, 'title', "text-sm font-bold text-slate-900 leading-tight", ZoneComponent)}
                        
                        {subtitle.value && (
                            <div className="flex items-center gap-1">
                                {subtitle.icon && React.createElement(subtitle.icon, { className: "w-3 h-3 inline-block mr-1 text-slate-400" })}
                                {renderZoneContent(check, cardLayout, 'subtitle', "text-xs uppercase font-bold tracking-wide text-slate-500", ZoneComponent)}
                            </div>
                        )}

                        {body1.value && (
                            <div className="flex items-center gap-1">
                                {body1.icon && React.createElement(body1.icon, { className: "w-3 h-3 inline-block mr-1 text-slate-400" })}
                                {renderZoneContent(check, cardLayout, 'body1', "text-xs text-slate-600 leading-snug line-clamp-3", ZoneComponent)}
                            </div>
                        )}
                    </div>

                    {/* Flags (Sorted Short -> Long) */}
                    {hasFlags && (
                        <div className="flex flex-wrap gap-2 pt-2">
                            {sortedFlags.map(flag => {
                                const styles = getChipStyles(flag.color || '');
                                return (
                                    <span 
                                        key={flag.id}
                                        className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium border ${styles.wrapper} ${styles.text} ${styles.border}`}
                                        title={flag.name}
                                    >
                                        <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${flag.color || styles.dot}`}></span>
                                        {flag.name}
                                    </span>
                                );
                            })}
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="flex justify-between items-center px-4 py-3 border-t border-slate-200 bg-slate-50 text-slate-600 gap-2">
                    {footerLeft.value && (
                        <div className="flex items-center gap-1">
                            {footerLeft.icon && React.createElement(footerLeft.icon, { className: "w-3 h-3 inline-block mr-1 text-slate-400" })}
                            {renderZoneContent(check, cardLayout, 'footerLeft', "text-xs font-bold text-slate-900 flex items-center", ZoneComponent)}
                        </div>
                    )}
                    {footerRight.value && (
                        <div className="flex items-center gap-1">
                            {footerRight.icon && React.createElement(footerRight.icon, { className: "w-3 h-3 inline-block ml-1 text-slate-400" })}
                            {renderZoneContent(check, cardLayout, 'footerRight', "text-xs font-bold text-slate-900 flex items-center", ZoneComponent)}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};